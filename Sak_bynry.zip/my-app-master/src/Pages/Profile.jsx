import React from 'react'
import ProfilePage from '../component/profile-component/profile'

const Profile = () => {
  return (
    <div>
        <ProfilePage/>
    </div>
  )
}

export default Profile
